# GovCore TypeScript SDK

Independently authored, dependency-free runtime client for the versioned read API. Licensed under MIT; copyright 2026 metaforismo. Retain `LICENSE` and SPDX notices when embedding the client in a product. The core service has its own code license.

`GovCoreClient.resolve({istat_code})`, `getEntity(id)` and `routing(id,category)` issue bounded read-only GETs. Strict validation rejects unknown schema fields, mismatched identities, missing category evidence, expired reviews, future validity, malformed URLs and unusable status envelopes. HTTP is allowed only on loopback; HTTPS is required elsewhere. Responses never grant consent or action authority.

Use `npm ci`, `npm run check` and `npm test`. The optional DVNS adapter projects public institutional identifiers only. The isolated SuperPino product patch is a separate artifact outside this repository.

Build an installable JavaScript/declaration package with `npm ci`, `npm run build` and `npm pack`. The package exports compiled ESM under `dist/`, with `.d.ts` declarations and its MIT notice; vanilla Node does not need TypeScript stripping. No registry publication is configured. The packaging test installs the local tarball offline in a disposable directory and exercises both entry points. Source embedding retains the MIT license.

Resolved identifiers require current verified support and IPA comparisons ignore case. Entity endpoints require an explicit schema envelope; fact predicates/scalars and all declared intervals are validated. Requests and body reads enforce a deadline even for test fetchers that ignore cancellation.

For an existing page of public institutional identities, use `linkDvnsEntities(client, identities, {concurrency: 4})` from `@gov-core/client/dvns`. It returns an ordered `rows` array of `{ok: true, result}` or `{ok: false, error}` plus request/deduplication counts. `result.status` remains `resolved`, `ambiguous`, `not_found` or `conflict`; failures contain fixed codes, never remote diagnostics. Resolve results describe identity only and do not grant routing or action authority.

Inputs project only `ipaCode`, `taxCode` and corroborated `istatCode`. Empty/invalid rows receive `invalid_input` without a request. Deduplication compares the complete selector set and ignores IPA case; an extra identifier remains a separate query because it may reveal a conflict. Defaults: four workers, at most 1,000 input rows; concurrency may be 1–16 and `maxRows` may lower the 1,000-row hard ceiling. Each request uses the base client's bounded transport. No retries, cross-call cache or routing cache are added. A custom `resolve` implementation must preserve that client's timeout/validation contract.
